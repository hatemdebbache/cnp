# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, sqrt
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import derive
import racine

# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo1()
# ==============================================================
def exo1():
    x = 1.27
    wo = derive.dfc2(f, x, 0.1024)
    w1 = derive.dfc2(f, x, 0.0512)
    w2 = derive.dfc2(f, x, 0.0256)
    w3 = derive.dfc2(f, x, 0.0128)
    w4 = derive.dfc2(f, x, 0.0064)
    w5 = derive.dfc2(f, x, 0.0032)
    w6 = derive.dfc2(f, x, 0.0016)
    
    e1 = abs(w1 - wo)
    e2 = abs(w2 - w1)
    e3 = abs(w3 - w2)
    e4 = abs(w4 - w3)
    e5 = abs(w5 - w4)
    e6 = abs(w6 - w5)
    
    print(e1)
    print(e2)
    print(e3)
    print(e4)
    print(e5)
    print(e6)
    
# ==============================================================
def exo2():
    pass
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    return sqrt(x)
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
