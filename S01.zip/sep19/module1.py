# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import cbase


# -----
gBETA = 0.1234
# ==============================================================
def main():
    exo1()
# ==============================================================
def exo1():
    graphe.FixeEchelle(-5, 5, -5, 5)
    graphe.TraceAxes()
    graphe.TraceFonc(f, -5, 2,npts=101, epaisseur=3.0, couleur='red', relie = False)
    graphe.TraceFonc(f, 2, 5,npts=101, epaisseur=3.0, couleur='green', relie = True)
    plt.show()
# ==============================================================
def exo2():
    a = 3
    b = 4
    
    a,b = b,a
    print(a,b)
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    return 1 + cbase.signe(x) - x
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
