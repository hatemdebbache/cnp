"# progremme de resodre lequation de 2 eme degree :"
    
import math
b=float(input('b='))
c=float(input('c='))
delta=b**2-4*c
if delta >0 :
    x=(-b-math.sqrt(delta))/2
    y=(-b+math.sqrt(delta))/2
    if abs(x)>abs(y):
        print('les solutions sont:','x=',format(x,'.2f'),'et','y=',format(y,'.2f'))
    else:
        z=x
        x=y
        y=z
        print('les solutions sont:','x=', x,'et','y=',y)
elif delta==0 :
    x=-b/2
    print('la solution est:','x=',format(x,'.2f'))
else:
    delta=abs(delta)
    print('les solutions sont','x=',-b/2,'-i',format((math.sqrt(delta)/2),'.2f'),'et',"   ",'y=',-b/2,'+i',format((math.sqrt(delta)/2),'.2f'))           