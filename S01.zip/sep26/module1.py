# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import disque


# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo2()
# ==============================================================
def exo1():
    x = 5.76
    y = 1e6*x
    print(y)
    
    n = 1000000
    z = 0.
    for i in range(0,n):
        z += x
    
    print(z)
# ==============================================================
def exo2():
    x = 1e-13
    y = 4325 + x
    print(y)
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    return exp(-gBETA * x**2)
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
