# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import disque


# -----
gBETA = 0.1234
# ==============================================================
def main():
    # a = np.array([[1, 4], [5, 6]])
    # print(a)
    # exo()
    # exemple1()
    exemple2()
    # exemple3()
    # exemple4()
# ==============================================================
def exemple1():
    y = f1(0.3) ;  z = ali(0.6)
    t=float(0.004535165465431)
    print(y, z)
    print('y = %e, z = %f'%(y, t))
    print('La valeur de y+z est {0:1.3f}'.format(y+z))
    print('La valeur de t est {0:0.5e}'.format(t))
# ==============================================================
def exo():
    global y
    x=np.zeros(6)
    y=np.zeros(6)
    for i in range(5):
        x[i]=i
        y[i]=ali(x[i])
        
    graphe.FixeEchelle(0, 0.1, 0, 2)
    graphe.TraceAxes()
    graphe.TracePoints(x, y)
    plt.show()
# ==============================================================
def exemple2():
    graphe.FixeEchelle(0, 5.1, -4, 6)
    graphe.TraceAxes()
    graphe.TraceFonc(g, 0, 5.5)
    graphe.TraceFonc(g1, 0, 5.5, couleur='cyan')
    graphe.TraceFonc(g2, 0, 5.5, couleur='red')
    #graphe.TraceFonc(ali, -1, 3, couleur='cyan')
    plt.show()
# ==============================================================
def exemple3():
    npts, x, y = disque.LireVec2('data1.txt')
    print(x) ;  print(y) ;  print(npts)
    graphe.FixeEchelle(-11, 11, -11, 11)
    graphe.TraceAxes()
    graphe.TracePoints(x, y)
    plt.show()
# ==============================================================
def exemple4():
    N, M, A, b = disque.LireSys('C:/Users/4-088/Desktop/journaux/data2.txt')
    print(N) ;  print(M) ;  print(A) ;   print(b)
    
# ==============================================================

               
# ==============================================================
def f1(x):
    return exp(-gBETA * x**2)
# ==============================================================
def ali(x):
    return sin(pi * x)
# ==============================================================
def g(x):
    return 5 * exp(-0.5 * x) * sin(75*0.1 * x + 2) + 3 / 2
# ==============================================================
def g1(x):
    return 5 * exp(-0.5 * x) * sin(75*0.15 * x + 2) + 3 / 2
# ==============================================================
def g2(x):
    return 5 * exp(-0.5 * x) * sin(75*0.2 * x + 2) + 3 / 2
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
