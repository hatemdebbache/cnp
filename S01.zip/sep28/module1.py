# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, cos
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import derive


# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo1()
# ==============================================================
def exo1():
    x = 0.35
    v = danis(x)
    w = derive.dfp1(anis, x, 0.001)
    print(abs(w-v))
    w = derive.dfc2(anis, x, 0.001)
    print(abs(w-v))
# ==============================================================
def exo2():
    pass
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def anis(x):
    return sin(x)
# ==============================================================
def danis(x):
    return cos(x)
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
