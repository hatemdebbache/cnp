# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, sqrt
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import disque


# -----
gBETA = 0.1234
# ==============================================================
def main():
    exo2()
# ==============================================================


def exo1():
    x,y,z = samia(3.,4.)
    print(x,y,z)
    u,v,w = samia(2.,7.)
    print(u,v,w)
# ==============================================================
def exo2():
    graphe.FixeEchelle(-0.1, 1.1, -0.1, 1.1)
    graphe.TraceAxes()
    graphe.TraceFonc(idris, 0, 1)
    graphe.TraceFonc(amine, 0, 1, couleur='red')
    plt.show()
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def samia(a,b):
    
    p = 2.*(a + b)
    s = a*b
    d = sqrt(a*a + b*b)
    
    return p,s,d
# ==============================================================
def f(x):
    return exp(-gBETA * x**2)
# ==============================================================
def idris(x):
    return exp(-0.1239*x)
# ==============================================================
def amine(x):
    return sin(0.5*pi*x)
# ==============================================================

if (__name__ == "__main__"):
    
    main()
# ==============================================================
