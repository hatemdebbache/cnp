# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, tan, cos, tanh, sinh, sqrt
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "E:/EMP/CNP/BIBLIO/")
import graphe
import disque
import cbase

# -----
gBETA = 0.1433
# ==============================================================
def main():
    # exo1()
    # exo2()
    # exo3()
    # exo4()
    # exo5()
    # exo6()
    # exo7()
    
    return
# ==============================================================
def exo1():
    graphe.FixeEchelle(0, 2, -2, 2)
    graphe.TraceAxes()
    graphe.TraceFonc(f, 0, 2)
    graphe.TraceFonc(g, 0, 2)
    plt.show()
# ==============================================================
def exo2():
    graphe.FixeEchelle(-2.2, 5, 0, 6)
    graphe.TraceAxes()
    graphe.TraceFonc(l, -2.2, 5)
    plt.show()
# ==============================================================
def exo3():
    graphe.FixeEchelle(-10, 10, -10, 10)
    graphe.TraceAxes()
    graphe.TraceFonc(p, -10, 10)
    plt.show()
# ==============================================================
def exo4():
    pass
# ==============================================================
def exo5():
    graphe.FixeEchelle(-5, 5, -1.5, 1.5)
    graphe.TraceAxes()
    graphe.TraceFonc(Heaviside, -5, 5)
    plt.show()
# ==============================================================
def exo6():
    graphe.FixeEchelle(-50, 50, -1, 1)
    graphe.TraceAxes()
    graphe.TraceFonc(suite, -50, 50)
    plt.show()
# ==============================================================
def exo7():
    c = [0,0]
    r = 1
    p1 = [2,-2]
    p2 = [2,2]
    print(intersection_cercle(c, r, p1, p2))
# ==============================================================
def f(x):
    return exp(-x**2)*sin(pi*x)
# ==============================================================
def g(x):
    return cos(100*gBETA*x)
# ==============================================================
def p(x):
    return (tanh(x/3) + x*x - 1) / (sinh(x) - x*x + 1)
# ==============================================================
def l(x):
    a = 0.1*exp(-2*x**3)
    b = sin(exp(x)) / cos(3*pi*x)
    c = 3*sin(0.75*pi*sqrt(x))
    return (a + b - (b*c*a) + a**3 + sqrt(c**2 + 1)) / 8 + 3
# ==============================================================
def Heaviside(x):
    # return 0 if x<0 else 0.5 if x==0 else 1
    return 0.5*(1+signe2(x))
# ==============================================================
def rectangle(x):
    # return 1 if (x>=a and x<=b) else 0
    # r = h(x-a)-h(x-b)
    # r = h(x-1)*h(b-x)
    a,b = 1,1.5
    return Heaviside(x-a)*Heaviside(b-x)
# ==============================================================
def signe2(x):
    return tanh(1e9*x)
# ==============================================================
def suite(x):
    a = x 
    b = (7 + gBETA)*x
    for i in range(98):
        c = (1 - 0.5*gBETA)*sin(0.5*pi*b) + 0.5*gBETA*cos(0.5*pi*a)
        a, b = b, c

    return c
# ==============================================================
def intersection_cercle(c, r, p1, p2):
    """
        Check the intersection status of a circle of center c (1-D array with coordinates) and rayon r
            with a line segment between the points p1 and p2 (1-D arrays with coordinates)
    
        Return:
            0   The segment doesn't intersect with the circle (or the segment intersects with the circle in one point, 
                    the other point is out of domain)
            1   The line is tangent to the circle
            2   The segment intersects with the circle in two different points
    """
    xc, yc = c
    x1, y1 = p1
    x2, y2 = p2
    
    a = (x2-x1) 
    b = (y2-y1) 
    c = (xc+x1) 
    d = (yc+y1)
    
    a1 = 2*(a*c + b*d)/(a**2 + b**2)
    a2 = (c**2 + d**2 - r**2)/(a**2 + b**2)
    
    s, x, y = cbase.esd(a1, a2)
    if s == 1:
        if (x >= 0 and x <= 1) and (y >= 0 and y <= 1):
            return 2
        return 0
    else:
        return 1 + s
# ==============================================================
if (__name__ == "__main__"):

    main()