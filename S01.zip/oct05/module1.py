# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import quadra
import derive

# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo3()
# ==============================================================
def exo1():
    V = 1. - exp(-1.)
    W1 = quadra.comp_Trapeze(samir, -1, 0, 4000)
    W2 = quadra.comp_PointMilieu(samir, -1, 0, 5)
    W3 = quadra.comp_Simpson(samir, -1, 0, 2)
    print(abs(W1 - V))
    print(abs(W2 - V))
    print(abs(W3 - V))
# ==============================================================
def exo2():
    V = exp(0.32)
    W = derive.dfc23(samir, 0.32, 1e-3)
    print(V)
    print(W)
    print(abs(W - V))
# ==============================================================
def exo3():
    V = 1. - exp(-1.)
    # W1 = quadra.comp_Trapeze(samir, -1, 0, 4000)
    W2 = quadra.comp_PointMilieu(samir, -1, 0, 5)
    # W3 = quadra.comp_Simpson(samir, -1, 0, 2)
    # print(abs(W1 - V))
    print(abs(W2 - V))
    # print(abs(W3 - V))
    
    W2 = quadra.comp_PointMilieu(samir, -1, 0, 10)
    print(abs(W2 - V))
    
    W2 = quadra.comp_PointMilieu(samir, -1, 0, 20)
    print(abs(W2 - V))

# ==============================================================
def exo4():
    pass
# ==============================================================
def samir(x):
    return exp(x)
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
