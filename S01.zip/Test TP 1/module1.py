# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, cos, tanh, asin, atan, sqrt
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import derive
import quadra
from MatVec import modif_mat, dot_m, trace, vec_interval, dot_v

# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo3()
# ==============================================================
def exo1():
    graphe.FixeEchelle(-8, 8, -8, 8)
    graphe.TraceAxes()
    graphe.TraceFonc(f, -8, 8, 100001)
    plt.show()
# ==============================================================
def exo2():
    x = 1.4
    wc = derive.dfc2(g, x, 0.01)
    wr = derive.dfr2(g, x, 0.01)
    wp = derive.dfp2(g, x, 0.01)
    print(wc, wr, wp)
    
    w2 = derive.dfc22(g, x, 0.01)
    w3 = derive.dfc23(g, x, 0.01)
    print(w2, w3)
# ==============================================================
def exo3():
    wpm = quadra.comp_PointMilieu(L, 0, 2, 200)
    wt = quadra.comp_Trapeze(L, 0, 2, 200)
    ws = quadra.comp_Simpson(L, 0, 2, 200)
    print(wpm, wt, ws)
    
    v = 0.1*(1 - cos(20*gBETA))/gBETA
    Nsub = 1
    w = quadra.comp_Trapeze(L, 0, 2, Nsub)
    while(abs(w-v) > 1e-5):
        Nsub *= 2
        w = quadra.comp_Trapeze(L, 0, 2, Nsub)
        
    print(Nsub) 
    
    Nsub = 1
    w = quadra.comp_Simpson(L, 0, 2, Nsub)
    while(abs(w-v) > 1e-5):
        Nsub *= 2
        w = quadra.comp_Simpson(L, 0, 2, Nsub)
        
    print(Nsub) 
# ==============================================================
def exo4():
    A = np.zeros((6,6))
    B = np.zeros((6,6))
    
    # Creation de A
    for j in range(6):
        A[0, j] = (10*gBETA)**(j + 1)
        A[1, j] = gBETA**(1/(j + 1))
        A[2, j] = (10*gBETA)**(-j - 1)
        A[3, j] = (10*gBETA)**(j + 1)
        A[4, j] = gBETA**(1/(j + 1))
        A[5, j] = (10*gBETA)**(-j - 1)
    
    # Creation de B
    modif_mat(B, 1, 0, 0, 2, 2)
    modif_mat(B, 3, 0, 3, 5, 5)
    modif_mat(B, 2, 0, 4, 2, 4)
    modif_mat(B, 4, 3, 0, 4, 1)
    modif_mat(B, 6, 3, 4, 5, 5)
    
    # Calcule de C
    C = dot_m(A, B)
    print(C[3,3], C[4,2], trace(C))
# ==============================================================
def exo5():
    x, y = discretise_fonction(f, -4, 0, 1000)
    print(y[100], y[450])
    print(max_element(y))
    print(min_element(y))
    u = y[:500]
    v = y[500:]
    print(dot_v(u, v))
# ==============================================================
# def f(x):     # f de exo1
#     bx = gBETA*x
#     return 50*gBETA*exp(-20*bx*bx*bx*bx)*cos(200*bx*bx)*tanh(-20*bx*bx)
# ==============================================================
def max_element(A):
    n = len(A)
    maxi = A[0]
    imaxi = 0
    for i in range(1,n):
        if A[i] > maxi:
            maxi, imaxi = A[i], i
    return maxi, imaxi
# ==============================================================
def min_element(A):
    n = len(A)
    mini = A[0]
    imini = 0
    for i in range(1,n):
        if A[i] < mini:
            mini, imini = A[i], i
    return mini, imini
# ==============================================================
def discretise_fonction(f, xmin, xmax, npts):
    """ 
        Return list of function values for n point in interval [xmin, xmax]
    """
    x = vec_interval(xmin, xmax, npts)
    y = np.zeros(npts)
    for i in range(npts):
        y[i] = f(x[i])
    
    return x, y
# ==============================================================
def g(x):
    return x*x*(tanh(sin(gBETA*x*x)) + asin(x/pi))/(atan(sqrt(gBETA)*x*x) + exp(-gBETA*x*x*x*x))
# ==============================================================
def L(x):
    return sin(10*gBETA*x)
# ==============================================================
def f(x):
    a = 10*gBETA*x + 3
    b = x + 4
    return (a*a + tanh(sqrt(b)))/(a*a*a*a + tanh(sin(b)))
# ==============================================================

if (__name__ == "__main__"):
    
    main()
# ==============================================================
