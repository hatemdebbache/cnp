# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, log
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import quadra


# -----
gBETA = 0.1234
# ==============================================================
def main():
    exo1()
# ==============================================================
def exo1():
    S1 = quadra.comp_Simpson(f, 1., 4.6, 3)
    S2 = quadra.comp_Simpson2(f, 1., 4.6, 2)
    
    v = log((4.6 + gBETA)/(1. + gBETA))
    print(v)
    print(abs(S1-v))
    print(abs(S2-v))
# ==============================================================
def exo2():
    pass
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    return 1/(x + gBETA)
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
