# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, tanh
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import disque
import cbase

# -----
gBETA = 0.1234
# ==============================================================
def main():
    exo2()
# ==============================================================
def exo1():
    b = 1e6
    c = 1e-4
    s, x, y = cbase.ESD(b,c)
    print(s,x,y)
    s, x, y = cbase.esd(b,c)
    print(s,x,y)
# ==============================================================
def exo2():
    x = 2.38
    print(tanh(x))
    print(TANH(x))
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    return exp(-gBETA * x**2)
# ==============================================================
def TANH(x):
    if (x > 0):
        v = exp(-2*x)
        y = (1 - v)/(1 + v)
    else:
        v = exp(2*x)
        y = (v - 1)/(v + 1)
    
    return y
# ==============================================================

if (__name__ == "__main__"):
    
    main()
# ==============================================================
