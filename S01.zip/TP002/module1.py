# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, cos, tanh, sqrt
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
from MatVec import *

# -----
gBETA = 0.1433
# ==============================================================
def main():
    # exo1()
    # exo2()
    # exo3()
    # exo3()
    # exo4()
    # exo5()
    
    return 
# ==============================================================
def exo1():
    # for  i in reversed(range(6)):
    #     print(i)
    
    # print(suite(200, 16, 0.5))
    # n = 1
    # u = suite(n, 144, 0.5)
    # while(u<=12 or u>=12.06):
    #     n += 1
    #     u = suite(n, 144,0.5)
    # print(n)
    
    graphe.FixeEchelle(-4, 4, -1, 1)
    graphe.TraceAxes()
    graphe.TraceFonc(f, -4, 4)
    plt.show
    print(trouver_abscisse(f))
# ==============================================================
def exo2():
    print(vec_valeur(6, 4))
# ==============================================================
def exo3():
    theta = vec_interval(0, 2*pi, 100)
    x, y = create_circle(theta, 2, 0, 0)
    graphe.TraceAxes()
    graphe.FixeEchelle(-2.5, 2.5, -2.5, 2.5)
    graphe.TracePoints(x, y)
    plt.show
    # print(theta)
    # print(vec_interval(0, 4, 5))
    # print(copie_vec(np.zeros(2)))
# ==============================================================
def exo4():
    x, y = discretise_fonction(sin, -1, 1, 21)
    graphe.TraceAxes()
    graphe.FixeEchelle(-1.5, 1.5, -1.5, 1.5)
    graphe.TracePoints(x, y)
    plt.show
# ==============================================================
def exo5():
    x = np.zeros((9,9))
    # les 1s
    modif_mat(x, 1, 0, 0, 1, 2)
    modif_mat(x, 1, 0, 3, 0, 4)
    # les 2s
    modif_mat(x, 2, 0, 5, 0, 8)
    # les 3s
    modif_mat(x, 3, 1, 3, 2, 5)
    # les 7s
    modif_mat(x, 7, 1, 6, 3, 8)
    modif_mat(x, 7, 3, 3, 5, 8)
    # les 8s
    modif_mat(x, 8, 6, 0, 8, 3)
    # les 9s
    modif_mat(x, 9, 6, 4, 8, 8)
    print(x)
# ==============================================================
def f(x):
    a = x + 3
    b = x + 4
    return (a**2 + tanh(sqrt(b)))/(a**4 + tanh(sin(b))) - 1
# ==============================================================
def suite(k, a, u):
    if k<=0 or a<=0:
        raise ValueError("k and a must be >0")
    for i in range(k):
        u = 0.5*(u + a/u)
    return u
# ==============================================================
def trouver_abscisse(f, a, pas = 0.1):
    """
        Return the first (approx.) point x where f(x) = 0
        
        approxi.: only equidistant points are considered with intervals of error of 'pas'
    """
    x = a
    n = 2
    a = f(x)
    b = f(x+pas)
    while(a*b >= 0):
        n += 1
        x += pas
        a = b
        b = f(x+pas)

    return x + 0.5*pas, n
# ==============================================================
def nb_nul(f, a, b, pas = 0.1):
    """ 
        Return the (approx.) number of occurences of f(x) = 0
        
        approxi.: only equidistant points are considered with intervals of error of 'pas'
    """
    x = a
    n = 0
    while(x < b):
        x = trouver_abscisse(f, x)
        n = n + 1
    
    return n
# ==============================================================
def create_circle(theta, r, xo, yo):
    """ 
        Return the coordinates (x,y) of the arc of center (xo, yo), rayon r, and angle theta
    """
    n = len(theta)
    x = np.zeros(n)
    y = np.zeros(n)
    for i in range(n):
        x[i] = xo + r*cos(theta[i])
        y[i] = yo + r*sin(theta[i])
    return x, y
# ==============================================================
def discretise_fonction(f, xmin, xmax, npts):
    """ 
        Return list of function values for n point in interval [xmin, xmax]
    """
    x = vec_interval(xmin, xmax, npts)
    y = np.zeros(npts)
    for i in range(npts):
        y[i] = f(x[i])
    
    return x, y
# ==============================================================
def representation_base(x, b):
    """
        Returns the representation of an integer x in base b.
    """
    ret = ""
    if b > 35:
        print("Where THE F* are you going with that?")
    y = []
    alph = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    while(x > 0):
        rest = x%b
        if rest >= 10:
            rest = alph[rest - 10]
        y.append(rest)
        x = x//b
    for i in reversed(y):
        ret += str(i)
    
    return ret # Other forms of representation can be adopted later on
# ==============================================================
def reste_division(a, b):
    """
        Return the rest of the division of a by b == a%b (using loop of diff.)
    """
    while(a>b):
        a -= b
    return a
# ==============================================================
def moment(n, Pend):
    v = []
    if len(Pend) != 3 or Pend.ndim != 1:
        raise ValueError("Must provide the coordinates of Pend in a cartesian base")
    x, y, z = Pend
    x, y, z = vec_interval(0, x, n), vec_interval(0, y, n), vec_interval(0, z, n)
    pts = []
    for i in range(n):
        pts.append([x[i], y[i], z[i]])
    for point in pts:
        v.append(module(cross_v(point, force(point))))
    return np.array(v)
# ==============================================================
def force(P):
    if len(P) != 3 or P.ndim != 1:
        raise ValueError("Must provide the coordinates of P in a cartesian base")
    ret = np.zeros(3)
    ret[0] = P[0] + P[1]
    ret[1] = sqrt(ret[1]*P[0]*P[1]*P[2])
    ret[2] = 0.5*ret[0]/(P[2] + 0.1)
    
    return ret
# ==============================================================
if (__name__ == "__main__"):
    main()
# ==============================================================
