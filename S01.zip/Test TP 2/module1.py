# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, cos, log
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import racine
import derive
import quadra

# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo1()
    exo2()
    exo3()
    # exo4()
    # exo5()
# ==============================================================
def exo1():
    print()
    # graphe.FixeEchelle(0, 1, -1, 1)
    # graphe.TraceAxes()
    # graphe.TraceFonc(H, 0, 1, npts=1001)
    # graphe.TraceFonc(L, 0, 1, npts=1001)
    # plt.show()
    
    print("################ \n Reponse (1)/2/a\n################")
    a, b = 0., 1.
    e = 1e-6
    cmax = 20
    xn = racine.Newton_Raphson(d, a, b, e, cmax, 0.5)
    xp = racine.Point_Fixe(w, a, b, e, cmax, 0.5)
    xs = racine.Secante(D, a, b, e, cmax, 0.5, 0.7)
    xr = racine.Regula_Falsi(D, a, b, e, cmax)  
    print("Les couts\n################")
    print(xn[0])
    print(xp[0])
    print(xs[0])
    print(xr[0])
    
    print("Les valeurs\n################")
    print(format(xn[1], '.10g'))
    print(format(xp[1], '.10g'))
    print(format(xs[1], '.10g'))
    print(format(xr[1], '.10g'))
    
    print("Les erreurs\n################")
    print(format(xn[2], '.2g'))
    print(format(xp[2], '.2g'))
    print(format(xs[2], '.2g'))
    print(format(xr[2], '.2g'))
    
    print("################ \n Reponse (1)/2/b\n################")
    xn = racine.Newton_Raphson(d, 0., 1., 0., 2, 0.5)
    print(format(xn[1], '.10g'))
    print(format(xn[2], '.2g'))
    
    print("################ \n Reponse (1)/2/c\n################")
    print(racine.Point_Fixe(ww, 0., 1., 1e-6, 50, 0.5))
# ==============================================================
def exo2():
    print()
    V = log((2 + gBETA)/(1 + gBETA))
    print("################ \n Reponse (2)/1\n################")
    print(format(V, '.7g'))
    
    print("################ \n Reponse (2)/2\n################")
    a, b = 1., 2.
    Nsub = 40
    wt = quadra.comp_Trapeze(R, a, b, Nsub)
    wp = quadra.comp_PointMilieu(R, a, b, Nsub)
    ws = quadra.comp_Simpson(R, a, b, Nsub)
    ws2 = quadra.comp_Simpson2(R, a, b, Nsub)
    
    print(format(wt, '.7g'))
    print(format(wp, '.7g'))
    print(format(ws, '.7g'))
    print(format(ws2, '.7g'))
    
    print("################ \n Reponse (2)/3\n################")
    t10 = quadra.comp_Trapeze(R, a, b, 10)
    t5 = quadra.comp_Trapeze(R, a, b, 5)
    print(format(t10, '.7g'), format(abs(t10 - V), '.2g'), format(abs(t10 - t5), '.2g'))
    
    print("################ \n Reponse (2)/4\n################")
    D = -(1 + gBETA)**(-2)
    W = derive.dfc2(R, 1., 0.001)
    W2 = derive.dfc2(R, 1., 0.002)
    print(format(D, '.7g'), format(W, '.7g'), format(abs(D - W), '.2g'), format(abs(W - W2), '.2g'))  
    
# ==============================================================
def exo3():
    print()
    a, b = 1., 2.
    Nsub = 40
    
    print("################ \n Reponse (3)/1\n################")
    I = quadra.comp_Simpson(z, a, b, Nsub)
    print(format(I, '.7g'))
    
    # graphe.FixeEchelle(1., 2., 0., 0.5)
    # graphe.TraceAxes()
    # graphe.TraceFonc(Q, 1., 2., npts=1001)
    # plt.show()
    
    print("################ \n Reponse (3)/2\n################")
    print(format(Q(1.2), '.7g'), format(Q(2.), '.7g'))
    
    print("################ \n Reponse (3)/3\n################")
    v = racine.Dichotomie(q, 1.4, 2., 1e-6, 100)
    print(format(v[1], '.7g'))
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    return 
# ==============================================================
def H(x):
    return sin(10*gBETA*x - pi/4)
# ==============================================================
def L(x):
    return -(gBETA**2)*(x**3) - x/gBETA + gBETA**5
# ==============================================================
def D(x):
    return H(x) - L(x)
# ==============================================================
def d(x): # D(x)/D'(x) === (H(x) - L(x))/(H'(x) - L'(x))
    return D(x)/(10*gBETA*cos(10*gBETA*x - pi/4) + 3*(gBETA*x)**2 + 1/gBETA)
# ==============================================================
def w(x): # D(x) = 0 === w(x) = x
    return gBETA*(gBETA**5 - (gBETA**2)*(x**3) - sin(10*gBETA*x - pi/4))
# ==============================================================
def ww(x): # 10*H(x) - L(x) = 0 === ww(x) = x
    return gBETA*(gBETA**5 - (gBETA**2)*(x**3) - 10*sin(10*gBETA*x - pi/4))
# ==============================================================
def R(x):
    return 1/(gBETA + x)
# ==============================================================
def z(x):
    return exp(-gBETA*x*x)/((x + gBETA)**2)
# ==============================================================
def Q(x):
    return quadra.comp_Simpson(z, 1, x, 40)
# ==============================================================
def q(x):
    return Q(x) - 1/4
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
