# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, cos, log, sqrt
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import quadra
import derive
import racine

# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo1()
# ==============================================================
def exo1():
    # Vderive
    
    x = 10*gBETA
    cmax = 13
    e = 1e-11
    n, p = 6, 3
    c, D = derive.Richardson2(R, x, 0.2048, n, p)
    print("#######      Richardson      ########")
    for i in range(n):
        for j in range(p):
            print("%.12g " % D[i,j], end=' ')
        print('')
    echap = abs(D[n-1, p-1] - D[n-2, p-1])
    print("D = %.12g    c = %d      echap = %.2g"%(D[n-1,p-1], c, echap))

    # Vintegral
    a, b = 8*gBETA, pi - gBETA
    cmax = 40
    e = 1e-7
    n, p = 6, 3
    c, I = quadra.Romberg(R, a, b, n, p)
    print("#######      Romberg      ########")
    for i in range(n):
        for j in range(p):
            print("%.12g " % I[i,j], end=' ')
        print('')
    echap = abs(I[n-1, p-1] - I[n-2, p-1])
    print("I = %.12g    c = %d      echap = %.2g"%(I[n-1,p-1], c, echap))
    # print(quadra.comp_Trapeze(R, a, b, 8))
# ==============================================================
def exo2():
    # xmin, xmax = 1.5, 2.5
    # ymin, ymax = -5., 5.
    # graphe.FixeEchelle(xmin, xmax, ymin, ymax)
    # graphe.TraceAxes()
    # graphe.TraceFonc(H, xmin, xmax, npts=1001)
    # graphe.TraceFonc(L, xmin, xmax, npts=1001)
    # plt.show()
    # print("###### INTERSECTION H ET L #######")
    a, b = 1.5, 2.5
    e = 1e-5
    cmax = 100
    c, v, ee = racine.Regula_Falsi(HL, a, b, e, cmax)
    # print("W = %.12g    c = %d      echap = %.2g" % (v, c, ee))
    
    print("######## SURFACE ENTRE H ET L #######")
    a, b = 0., pi
    S = quadra.comp_Simpson2(D, a, b, 33)
    print("S[0,pi] = %.6g " % S)
    
    Nsub = 17
    S1 = quadra.comp_Simpson2(D, a, v, Nsub)
    S2 = quadra.comp_Simpson2(D, v, b, Nsub)
    print("S1[0,v] = %.6g      S2[v,pi] = %.6g\nS = S1+S2 = %.6g" % (S1, S2, S1+S2))
    
# ==============================================================
def exo3():
    X = [0., 0.2, 0.3, 0.45, 0.62, 0.735, 0.859, 1.05, 1.14, 1.21, 1.32, 1.415, 1.517, 1.62, 1.68, 1.8]
    Y = [-0.5-gBETA**2, -2/5+gBETA, 0.1-1.5*gBETA, 0.1*gBETA, 0.1, 0.18+gBETA, 0.38+gBETA, 0.6-gBETA**2, 0.7+0.1*gBETA, 0.8+gBETA/5, 0.9+0.5*gBETA, 1+0.1*gBETA, 1.1+gBETA, 1.1+gBETA, 1.2 + gBETA, 1.5]
    
    xmin, xmax = 0, 1.8
    ymin, ymax = -0.6, 1.5    
    graphe.FixeEchelle(xmin, xmax, ymin, ymax)
    graphe.TraceAxes()
    graphe.TracePoints(X, Y, epaisseur=1., couleur='r')    

    y = []
    a, b = 0.98, -0.5
    for x in X:
        y.append(a*x + b)
    graphe.TracePoints(X, y, epaisseur=1., couleur='b', relie=True)
    print("Ê = %.2g" % Qualite(X, Y, a, b))

    achap, bchap, R = regression_lineaire(X, Y)
    print("achap = %.6g     bchap = %.6g    R = %.6g" % (achap, bchap, R))

    y = []
    for x in X:
        y.append(achap*x + bchap)
    graphe.TracePoints(X, y, epaisseur=1., couleur='g', relie=True)
    print("Nouveau qualité aprés regression lineaire:\nÊn = %.2g" % Qualite(X, Y, achap, bchap))

    plt.show()
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    return exp(-gBETA * x**2)
# ==============================================================
def R(x):
    return 2*x + x*sin(2*sqrt(x))
# ==============================================================
def H(x):
    return 3*x*(2 - x)*(x + 1)*sin(x)*exp(abs(x) + gBETA) + 2
# ==============================================================
def L(x):
    return x*sin(x)/(1 + x*x) + 2
# ==============================================================
def HL(x):
    return H(x) - L(x)
# ==============================================================
def D(x):
    return abs(H(x) - L(x))
# ==============================================================
def Qualite(X, Y, a, b):
    S = 0.
    for x, y in zip(X, Y):
        S += (a*x + b - y)**2
    
    return S
# ==============================================================
def regression_lineaire(X, Y):
    n = len(X)
    Sx, Sy = sum(X), sum(Y)
    xm, ym = Sx/n, Sy/n
    
    CoV = 0.
    Varx = 0.
    Vary = 0.
    for x, y in zip(X, Y):
        Dx = x - xm
        Dy = y - ym
        CoV += Dx*Dy
        Varx += Dx*Dx
        Vary += Dy*Dy
    
    a = CoV/Varx
    b = ym - a*xm
    R = CoV/sqrt(Varx*Vary)
    return a, b, R
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
