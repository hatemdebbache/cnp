# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, log
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import racine
import quadra


# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo1()
# ==============================================================
def exo1():
    
    c, x, ee = racine.Newton_Raphson(g, 0., 10., 1e-10, 50, 0.6)
    print(x, ee, c)    
    
    c, x, ee = racine.Secante(f, 0., 10., 1e-10, 50, 0.6, 0.7)
    print(x, ee, c)
    
    c, x, ee = racine.Point_Fixe(w, 0., 10., 1e-6, 50, 0.6)
    print(x, ee, c)
    
    c, x, ee = racine.Regula_Falsi(f, 0.6, 0.7, 1e-6, 50)
    print(x, ee, c)
    
    c, x, ee = racine.Dichotomie(f, 0.6, 0.7, 1e-6, 50)
    print(x, ee, c)      
# ==============================================================
def exo2():
    pass
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    return log(1 + x) + x - 1 - gBETA
# ==============================================================
def g(x):
    return (log(1 + x) + x - 1 - gBETA)/(1 + 1/(1 + x))
# ==============================================================    
def w(x):
    return -log(1 + x) + 1 + gBETA
# ==============================================================    
def h(t):
    pass
# ==============================================================    
def F(x):
    return quadra.comp_Simpson(h, 0., x, 500) - 1
# ==============================================================    
if (__name__ == "__main__"):
    
    main()
# ==============================================================
