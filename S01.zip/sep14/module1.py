# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, sqrt
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import ctrl


# -----
gBETA = 0.1234
# ==============================================================
def main():
    exo4()
# ==============================================================
def exo1():
    x,y,z = samia(-3,4.)
    print(x,y,z)
    u,v,w = samia(2.,7.)
    print(u,v,w)
# ==============================================================
def exo2():
    graphe.FixeEchelle(-0.1, 1.1, -0.1, 1.1)
    graphe.TraceAxes()
    graphe.TraceFonc(idris, 0, 1)
    graphe.TraceFonc(amine, 0, 1, couleur='red')
    plt.show()
# ==============================================================
def exo3():
    graphe.FixeEchelle(-1, 3, -1, 1)
    graphe.TraceAxes()
    graphe.TraceFonc(f, 0, 3)
    plt.show()
# ==============================================================
def exo4():
    print( signe(-18) )
    
# ==============================================================
def samia(a,b):
    # ctrl des données
    if(a < 0):
        ctrl.erreur('samia', 'a negatif')
    if(b < 0):
        ctrl.erreur('samia', 'b negatif')    
    # debut du programme
    p = 2.*(a + b)
    s = a*b
    d = sqrt(a*a + b*b)
    
    return p,s,d
# ==============================================================
def f(x):
    return exp(-x)*sin(5*pi*x)
# ==============================================================
def signe(x):
    if(x > 0):
        y = 1
    elif(x < 0):
        y = -1
    else:
        y = 0
        
    return y
# ==============================================================
def idris(x):
    return exp(-0.1239*x)
# ==============================================================
def amine(x):
    return sin(0.5*pi*x)
# ==============================================================
def ESD(b,c):
    abs()
    
    
    return s, x, y
# ==============================================================

if (__name__ == "__main__"):
    
    main()
# ==============================================================
