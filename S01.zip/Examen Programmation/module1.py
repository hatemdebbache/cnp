
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, cos, sin, log, sqrt
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "E:\\EMP\\..CNP\\COURS\\BIBLIO")
import graphe
import cbase
import racine
import quadra
import derive
from cbase import affiche_tableau
# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo1()
    exo2()

# ==============================================================
def exo1():
    print("######## Exo 1 ########\n")
    
    X = [0.1*i for i in range(1,10)]
    Y = np.zeros(9)
    for i in range(9):
        Y[i] = f(X[i])
    
    print("######## Le tableau de f(x) ########")
    for y in Y:
        print(f'{y:.8g}')
    
    print("###### Question 2 ########")
    a, b = 0.1, 0.9
    c, V, e = quadra.Romberg(f, a, b, 1, 0., 4, 4)    
    affiche_tableau(V, 8)
    print(f'Meilleure approximation = {V[3,2]:.8g}')
    print(f'Ê = {V[3,2]-V[2,2]: .2g}')
    
    print("###### Question 3 #######")
    x = 0.5
    c, W, e = derive.Richardson2(f, x, 0.4, 0., 9, 4)
    affiche_tableau(W, 8)
    print(f'Meilleure approximation = {W[2,1]:.8g}')
    print(f'Ê = {W[2,1]-W[1,1]: .2g}')
    
# ==============================================================
def exo2():
    print("\n######## Exo 2 ########\n")
    
    t = Poly_T(150, 10*gBETA)
    print(f'T150(10BETA) = {t:.4g}')
    s = Somme_T(100, 10*gBETA)
    print(f'S100(10BETA) = {s:.4g}')
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def exo5():
    pass
# ==============================================================
def f(x):
    return abs(x + 1)/(exp(x) - gBETA)
# ==============================================================
def Poly_T(n, x):
    if (n==0):
        return 1
    if (n==1):
        return x
    T0 = 1
    T1 = x
    
    for k in range(1,n):
        T = 2*gBETA*x*T1 - gBETA*gBETA*T0
        T0, T1 = T1, T
        
    return T
# ==============================================================
def Somme_T(N, x):
    T = np.zeros(N)
    T[0] = 1
    T[1] = x
    for n in range(1,N-1):
        T[n+1] = 2*gBETA*x*T[n] - gBETA*gBETA*T[n-1]
    
    S = 1.
    for k in reversed(range(0, N)):
        S = S*T[k] + 1
    S += T[0]
    return S
# ==============================================================
if (__name__ == "__main__"):
    
    main()
    
# ==============================================================
