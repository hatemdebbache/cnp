# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, cos
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import quadra
import ctrl

# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo4()
# ==============================================================
def exo1():
    a, b = 0., 5.
    v = F(b) - F(a)
    c, t, ee = quadra.PV_trapeze(f, a, b, 1e-8, 300000)
    print(v)
    print(t, c, ee)
    print(abs(v - t))
# ==============================================================
def exo2():
    X = [2., 1.3, 5., -4., 0., 1.]
    Y = [1., 10., 11., 3., -1., 0.]
    
    S, D = calcul(X, Y)
    print(S, D)
# ==============================================================
def exo3():
    X = [1., 2., -1., 3., 4., -5.]
    Y = carre2(X)
    print(X)
    print(Y)
# ==============================================================
def exo4():
    X = [2., 5., 1.3, -4., 0., 1.]
    Y = [1., 10., 11., 3., -1., 0.]
    graphe.FixeEchelle(-5., 6., -3., 15.)
    graphe.TraceAxes()
    graphe.TracePoints(X, Y, epaisseur=3.0)
    graphe.TracePoints(X, Y, relie=True, epaisseur=1.0)
# ==============================================================
def f(x):
    return exp(-gBETA*x) + sin(x) - gBETA*x 
# ==============================================================
def F(x): # primitive de f(x)
    return -(exp(-gBETA*x)/gBETA + cos(x) + gBETA*x*x/2)
# ==============================================================
def calcul(X, Y):
    n = len(X)
    m = len(Y)
    if (m != n):
        ctrl.erreur('calcul', 'X et Y doivent être de même taille')
    S = 0.
    D = 0.
    for i in range(0, n):
       S = S + abs(X[i] + Y[i])
       D = D + abs(X[i] - Y[i])
    
    return S, D
# ==============================================================
def carre(X):
    n = len(X)
    for i in range(0, n):
        X[i] = X[i]*X[i]
# ==============================================================
def carre2(X):
    n = len(X)
    Y = np.zeros(n)
    for i in range(0, n):
        Y[i] = X[i]*X[i]
    
    return Y
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
