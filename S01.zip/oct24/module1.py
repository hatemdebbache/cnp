# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import cbase


# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo1()
# ==============================================================
def exo1():
    X = [-1., 0., 1.2, 3., 5.]
    Y = [4., -1.5, 0.6, -0.8, 2.3]
    graphe.FixeEchelle(-2, 6, -3, 5)
    graphe.TraceAxes()
    graphe.TracePoints(X, Y, epaisseur=3)
    graphe.TraceFonc(f, -2, 5)
    graphe.TraceFonc(g, -2, 5, couleur='red')
    graphe.TraceFonc(p, -2, 5, couleur='green')
    plt.show()
# ==============================================================
def exo2():
    pass
# ==============================================================
def exo3():
    pass
# ==============================================================
def exo4():
    pass
# ==============================================================
def f(x):
    X = [-1., 0., 1.2, 3., 5.]
    Y = [4., -1.5, 0.6, -0.8, 2.3]
    
    return cbase.Poly_Lagrange(X, Y, x)
# ==============================================================
def g(x):
    C = [1., 4., -3., 2., -1.]
    
    return cbase.Horner(C, x)
# ==============================================================
def p(x):
    return 1 + 4*x - 3*x*x + 2*x*x*x - x*x*x*x
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
