# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:15:34 2020

@author: user
"""
# %matplotlib auto
# %matplotlib inline
from math import exp, pi, sin, sqrt, log
import numpy as np
import matplotlib.pyplot as plt
import sys
# -----
sys.path.insert(0, "./../BIBLIO/")
import graphe
import racine
import cbase


# -----
gBETA = 0.1433
# ==============================================================
def main():
    exo3(f2, g2, w2)
# ==============================================================
def exo1():
    v = sqrt(2.)
    c, x, echap = racine.Newton_Raphson(g, 1., 10., 1e-8, 25, -2.)
    print(v)
    print(x, c, echap)
# ==============================================================
def exo2():
    print(racine.Newton_Raphson(gg, 0., 1., 0., 6, 1.))
    print(racine.Dichotomie(ff, 0., 1., 0., 20))
    print(racine.Regula_Falsi(ff, 0., 5., 0., 20))
    print(racine.Secante(ff, 0., 20., 0, 20, 0.1, 0.9))
    
# ==============================================================
def exo3(f, g, w):
    a, b, e, cmax = 0., 0.9, 1e-7, 100
    print(racine.Dichotomie(f, a, b, e, cmax))
    print(racine.Regula_Falsi(f, a, b, e, cmax))
    xo = 0.5
    print(racine.Newton_Raphson(g, a, b, e, cmax, xo))
    print(racine.Point_Fixe(w, a, b, e, cmax, xo))
    x0, x1 = 0.1, 0.8
    print(racine.Secante(f, a, b, e, cmax, x0, x1))
# ==============================================================
def exo4(f):
    xmin, xmax, ymin, ymax = -10., 10., -10., 10.
    graphe.FixeEchelle(xmin, xmax, ymin, ymax)
    graphe.TraceAxes()
    graphe.TraceFonc(f, xmin, xmax)
    plt.show
# ==============================================================
def f(x):
    return x*x - 2.
# ==============================================================
def g(x):
    return (x*x - 2.)/(2.*x)
# ==============================================================
def ff(x):
    return log(1. + x) + x - 1. - gBETA
# ==============================================================
def gg(x):
    return (log(1. + x) + x - 1. - gBETA)/(1. + 1./(1. + x))
# ==============================================================
def f1(x): # racine dans [1, 3] appr. 2
    return log(x + 1) - x*x + 3

def g1(x):
    return (log(x + 1) - x*x + 3)*(x + 1)/(-2*x*x - 2*x + 1)
# ==============================================================
def f2(x): # racine dans[0, 0.9] !!! n'est pas définie en 1
    return exp(x)/(x - 1) + 3

def g2(x):
    return (exp(x) + 3*x - 3)*(x - 1)*exp(-x)/(x - 2)

def w2(x):
    return exp(x) + 3*x - 2
# ==============================================================
def f3(x): # racine dans [0,1]
    return cbase.Horner([-5, 10, -2, 3, 0, 5], x)

def g3(x):
    return f3(x)/cbase.Horner([10, -2, 3, 0, 5], x)
# ==============================================================
if (__name__ == "__main__"):
    
    main()
# ==============================================================
